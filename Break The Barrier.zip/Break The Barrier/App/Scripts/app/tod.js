﻿$(document).ready(function () {
    lodThoughts();
})

function lodThoughts() {
    calltoAjax('/Home/GetAllThoughts', "GET", "", function (result) {
        var resultdata = $.parseJSON(JSON.stringify(result.data));
        $("#tblTOD").DataTable({
            "responsive": true,
            "autoWidth": false,
            "paging": true,
            "bDestroy": true,
            "ordering": true,
            "order": [],
            "info": true,
            "deferRender": true,
            "aaData": resultdata,
            "aoColumns": [
                {
                    "mData": "Category",
                    "sTitle": "Category",
                    "sWidth": "100px"
                },
                {
                    "mData": "Thought",
                    "sTitle": "Thought",
                    'bSortable': false,
                    "sWidth": "200px",
                },
                {
                    "mData": null,
                    "sTitle": "Action",
                    'bSortable': false,
                    "sWidth": "75px",
                    mRender: function (data, type, row) {
                        var html = '<div>';
                        if (row.IsLiked) {
                            html += '&nbsp;<span class="label label-success">Voting Done</span>';
                        }
                        else {
                            html += '&nbsp;<button type="button" data-toggle="tooltip" class="btn btn-sm btn-info"' + 'onclick="vote(' + row.ThoughtId + ')"  title="Vote"><i class="fa fa-thumbs-up"></i></button>';
                        }

                        html += '</div>'
                        return html;
                    }
                },
            ]
        });
    });
}

function vote(thoughtId) {
    todConfirm("Are you sure you want to vote?", "Confirm", function (isConfirmed) {
        if (isConfirmed) {
            var dataP = { ThoughtId: thoughtId};
            calltoAjax('/Home/Vote', "POST", dataP, function (result) {
                if (result.IsSuccess) {
                    todAlert(result.Message, 'Success', 'success');
                    lodThoughts();
                }
                else {
                    todAlert(result.Message, 'Error', 'error')
                }
            });
        }
    });
}

function calltoAjax(url, type, data, successCallback, errorCallback, doneCallback, cType) {
    $.ajax({
        type: type,
        contentType: cType || "application/json; charset=utf-8",
        url: url,
        data: (typeof data !== 'undefined' && data !== null && data !== '') ? JSON.stringify(data) : {},
        dataType: "json",
        beforeSend: function () {
            $.blockUI();
        },
        success: function (data, status, xhr) {
            if (typeof successCallback === 'function') {
                successCallback(data, status, xhr);
            }
            $.unblockUI();
        },
        error: function (xhr, status, errorThrown) {
            console.log('Error status: ' + xhr.status + errorThrown + ': ' + (typeof xhr.responseJSON != 'undefined' ? xhr.responseJSON.MessageDetail : errorThrown));
            todAlert();
        }
    }).done(function (data, status, xhr) {
        if (typeof doneCallback === 'function') {
            doneCallback(data, status, xhr);
        }
        $.unblockUI();
    });
}

function todAlert(message, title, messageType, btnCallback, autoHide) {
    swal({
        title: title || "Oops...",
        text: message || "Something went wrong!",
        type: messageType || "error",
        html: true,
        allowOutsideClick: (autoHide !== false), //sets default true
        allowEscapeKey: (autoHide !== false),
        closeOnCancel: (autoHide !== false),
    }, function (result) {
        if (typeof btnCallback === 'function') {
            btnCallback(result);
        }
    });
}

function todConfirm(message, title, btnCallback, autoHide, isHTMLData, closeOnConfirm, type) {
    swal({
        title: title || "Are you sure?",
        text: message || "Are you sure you want to do this?",
        type: type || 'warning',
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        closeOnCancel: true,
        allowOutsideClick: (autoHide === true), //sets default false,
        allowEscapeKey: (autoHide === true),
        closeOnConfirm: (closeOnConfirm === true),
        html: (isHTMLData === true)
    }, function (isConfirm) {
        if (typeof btnCallback === 'function') {
            btnCallback(isConfirm);
        }
    });
}